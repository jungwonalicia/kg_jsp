package bean;

//bbs테이블에 crud기능을 할 수 있는 db전담 클래스
//CRUD
public class BbsDAO {
	public void create() {

	}

	public void read() {

	}

	public void update() {

	}

	public void delete() {

	}
}
