package jsp02;

public class 계산기 {

	public void 더하다() {

	}

	public void 빼다() {

	}
}
