package bean;

public class ProductDAO {
	// 물건 리스트 전체 보기
	public void list() {
		// 1. jdbc드라이버설정
		// 2. db연결
		// 3. sql문 객체 생성
		// 4. sql문 mysql서버로 전송
		// 5. 검색결과를 ArrayList에 넣어서 return
	}

	// 리스트 중에서 선택한 물건 하나 보기
	public void one(ProductDTO dto) {
		// 1. jdbc드라이버설정
		// 2. db연결
		// 3. sql문 객체 생성
		// 4. sql문 mysql서버로 전송
		// 5. 검색결과를 dto2에 넣어서 return
	}
}
