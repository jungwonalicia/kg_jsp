package bean;

//DAO: Data Access Object
//db의 특정한 테이블에 접근해서 db처리 전담클래스
//처리: create, read, update, delete(CRUD)
public class MemberDAO {
	public void create() {

	}

	public void read() {

	}

	public void update() {

	}

	public void delete() {

	}
}
